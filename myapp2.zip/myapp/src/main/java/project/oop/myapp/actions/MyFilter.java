package project.oop.myapp.actions;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import project.oop.myapp.model.MyClass;

public class MyFilter {

	//controlla se vengono soddisfatti i requisiti per aggiungere un elemento alla lista degli elementi filtrati
	//si usa sia per i numeri che per le stringhe
	public static boolean Check(Object value, String operator, Object th) {
		
		//controlla se i parametri da confrontare sono numeri
		if (th instanceof Number && value instanceof Number) {
			
			//converte i due parametri da Oggetto generico a Number e in seguito a Double
			Double thC = ((Number)th).doubleValue();
			Double valueC = ((Number)value).doubleValue();
			
			//controlla se l' operatore inserito � "maggiore" o "minore" e ritorna true o false a seconda del confronto
			if (operator.equals(">")) {
				return valueC > thC;
			}else if (operator.equals("<")) {
				return valueC < thC;
			}
			
			//se l' operatore non � ne "maggiore" ne "minore" ritorna false
			return false;
			
		//controlla se i parametri da confrontare sono: uno la stringa e l' altro l' array di stringhe su cui eseguire il controllo 
		}else if(th instanceof String[] && value instanceof String) {
			
			//converte i due parametri da Oggetto generico a String e String[]
			String[] thC = (String[])th;
			String valueC = (String)value;
			
			//cicla per tutta la lunghezza dell' array di stringhe
			for(int i=0;i<thC.length;i++) {
				
				//se vogliamo controllare che la stringa appartenga all' array
				if (operator.equals("in")){
					
					if(valueC.contains(thC[i])) {
						return true;
					}
				
				//se vogliamo controllare che la stringa non appartenga all' array
				}else if(operator.equals("nin")){
					
					if(valueC.contains(thC[i])) {
						return false;
					}
				}
				
			}
			
			//questo blocco di if viene usato nel caso non trovi nessuna stringa contenuta
			//nell' array con "in" oppure nel caso che si trovi una stringa non contenuta
			//nell' array con "nin"
			if (operator.equals("in")){
					return false;
			}else if(operator.equals("nin")){
					return true;
			}
		}
		return false;
	}
	
	public static ArrayList<MyClass> runFilt(List<MyClass> src, String fieldName, String operator, Object value) {
		
		//creo la Lista che conterr� i risultati del filtro	
		ArrayList<MyClass> out = new ArrayList<MyClass>();
		
		//per ogni elemento della lista passata come parametro
		for(MyClass item : src) {
			
			try {
				
				//uso questo oggetto per poter ricavare i dati qualsiasi sia il campo che voglio filtrare (numero o stringa)
				Method m = item.getClass().getMethod("get"+fieldName.substring(0, 1).toUpperCase()+fieldName.substring(1),null);
				
				try {
					
					//dentro "tmp" ci finisce il risultato della chiamata del metodo precedente
					Object tmp = m.invoke(item);
					
					//se il dato soddisfa i criteri del filtro viene aggiunto alla Lista dei risultati
					if(Check(tmp, operator, value)) {
						out.add(item);
					}
					
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				}
				
			} catch (NoSuchMethodException e) {
				e.printStackTrace();
			} catch (SecurityException e) {
				e.printStackTrace();
			}					
		}
		
		return out;
	}
	
}
