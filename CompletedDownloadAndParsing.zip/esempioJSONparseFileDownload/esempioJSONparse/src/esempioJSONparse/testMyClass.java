package esempioJSONparse;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class testMyClass {
	
	public static void main(String[] args) {
		
		//inserico il carattere separatore del csv
		Pattern pattern = Pattern.compile(",");
		
		//creo una lista che conterr� oggetti del tipo MyClass
		List<MyClass> myList = new ArrayList<MyClass>();  
		
		try{
			
			//apro il file csv
			BufferedReader bufCSV = new BufferedReader(new FileReader("FundsBreakdown.csv"));
			
			//leggo la prima riga del file contenente il nome degli attributi perch� causerebbe errori di conversione successivamente
			String line = bufCSV.readLine();
			
			//eseguo le istruzioni seguenti per ogni riga del file csv
			while ((line = bufCSV.readLine()) != null ) {
				
				//ogni dato separato dalla virgola viene messo in un array di stringhe
				String[] bufline= pattern.split(line); 
				
				//aggiungo alla lista un oggetto creato con i dati precedentemente ricavati (e convertiti a seconda del tipo di attributi)
				myList.add(new MyClass(bufline[0],Integer.parseInt(bufline[1]),bufline[2],Long.parseLong(bufline[3]),Float.parseFloat(bufline[4])));
			}
			
			//chiudo il file csv
			bufCSV.close();
		
		}catch(FileNotFoundException e) {
			System.out.println("FILE INESISTENTE");
		}catch(IOException e) {
			System.out.println("ERRORE I/O");
		}catch(NumberFormatException e){	
			System.out.println("ERRORE DI CONVERSIONE");
		}catch(Exception e){	
			System.out.println("ERRORE GENERICO");
		}finally {
			
			//mostro a video tutti gli oggetti nella lista
			for(MyClass c : myList) {
				System.out.println(c.toString());
			}
		}
	}
}
