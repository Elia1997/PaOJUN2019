//CODICE BARBARAMENTE COPIATO DAGLI ESEMPI DISPONIBILI E OPPORTUNAMENTE MODIFICATO:
//usato per analizzare la pagina indicata dal PRIMO URL, trovare il SECONDO URL e scaricare il file CSV tramite il SECONDO URL.

package esempioJSONparse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.ParseException;

public class MyDownloadAndParse {

	public static void main(String[] args) {

		//inserisce del PRIMO URL nella variabile "url"
		String url = "http://data.europa.eu/euodp/data/api/3/action/package_show?id=breakdown-available-funds-by-theme-2007-2013";
		
		//(questo IF non mi � chiaro, � sicuro una furbata del prof)
		if(args.length == 1) {
			url = args[0];
		}
		
		try {
			
			//crea oggetto URLConnection per collegarsi al PRIMO URL
			URLConnection openConnection = new URL(url).openConnection();
			
			//(questa riga non mi � chiara)
			openConnection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
			
			//crea oggetto InputStream e ci mette il contenuto della pagina indicata dal PRIMO URL
			InputStream in = openConnection.getInputStream();
			
			//Dichiara due stringhe vuote
			String data = "";
			String line = "";
			 
			try {
				 
				//InputStreamReader serve a convertire i byte di InputStream in char
				InputStreamReader inR = new InputStreamReader(in);
			   
				//BufferedReader migliora l' efficienza di lettura di InputStreamReader
				BufferedReader buf = new BufferedReader(inR);

				//mette ogni riga del contenuto della pagina indicata dal PRIMO URL dentro la variabile "data"
				while ((line = buf.readLine()) != null ) {
					data+=line;
				}
			   
			} finally {
				 
			//chiude la connessione
			in.close();
			}
			
			//crea un oggetto JSON col parsing di "data"
			JSONObject obj = (JSONObject) JSONValue.parseWithException(data); 
			
			//mette dentro objI il campo "result"
			JSONObject objI = (JSONObject) (obj.get("result"));
			
			//mette dentro l' array objA il campo "resources"
			JSONArray objA = (JSONArray) (objI.get("resources"));
			
			//per ogni elemento dell' array objA
			for(Object o: objA){
				
				//se l' elemento � di tipo JSONObject
			    if ( o instanceof JSONObject ) {
			    	
			    	//copia il contenuto dell' elemento in "o1"
			        JSONObject o1 = (JSONObject)o; 
			        
			        //mette nella stringa "format" il valore del campo "format" dell' elemento
			        String format = (String)o1.get("format");
			        
			        //mette nella stringa "urID" il valore del campo "url" dell' elemento
			        String urlD = (String)o1.get("url");
			        
			        try {
			        	
			        	//se la stringa "format" contiente "CSV" (quello che ci interessa)
			        	if(format.contains("CSV")) {
			        		
			        		//scarica il file con URL=urID e lo salva come "ComradePolloSuper.csv"
			        		download(urlD, "FundsBreakdown.csv");
			        		System.out.println("FILE SCARICATO");
			        	}
			        }catch(FileAlreadyExistsException e) {
			        	System.out.println("IL FILE ESISTE GIA'");
			        }
			    }
			}
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void download(String url, String fileName) throws Exception {
	    try (InputStream in = URI.create(url).toURL().openStream()) {
	        Files.copy(in, Paths.get(fileName));
	    }
	}
}
