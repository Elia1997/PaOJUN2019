package esempioJSONparse;

//classe che modella gli oggetti del file csv

public class MyClass {
	
	private String memberState;
	private int thcode;
	private String theme;
	private long decidedOps;
	private float nationalSFCFpercent;
	
	public MyClass(String memberState,int thcode,String theme,long decidedOps,float nationalSFCFpercent) {
		this.memberState=memberState;
		this.thcode=thcode;
		this.theme=theme;
		this.decidedOps=decidedOps;
		this.nationalSFCFpercent=nationalSFCFpercent;
	}

	public String getMemberState() {
		return memberState;
	}

	public void setMemberState(String memberState) {
		this.memberState = memberState;
	}

	public int getThcode() {
		return thcode;
	}

	public void setThcode(int thcode) {
		this.thcode = thcode;
	}

	public String getTheme() {
		return theme;
	}

	public void setTheme(String theme) {
		this.theme = theme;
	}

	public long getDecidedOps() {
		return decidedOps;
	}

	public void setDecidedOps(long decidedOps) {
		this.decidedOps = decidedOps;
	}

	public float getNationalSFCFpercent() {
		return nationalSFCFpercent;
	}

	public void setNationalSFCFpercent(float nationalSFCFpercent) {
		this.nationalSFCFpercent = nationalSFCFpercent;
	}
	
	public String toString() {
		return memberState+" - "+thcode+" - "+theme+" - "+decidedOps+" - "+nationalSFCFpercent+" .";
	}
}