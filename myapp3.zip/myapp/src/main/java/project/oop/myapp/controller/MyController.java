package project.oop.myapp.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import project.oop.myapp.actions.MyDownloadAndParse;
import project.oop.myapp.actions.MyFilter;
import project.oop.myapp.actions.MyStats;
import project.oop.myapp.model.MyClass;

@RestController
public class MyController {
	
	//variabile che conterrà tutti gli oggetti del file e che verrà passata ai filtri e statistiche
	private List<MyClass> results= new ArrayList<MyClass>();
	
	//download e parsing del file all' avvio dell' app
	@EventListener(ApplicationReadyEvent.class)
	public void downloadAfterStartup() {
	    results=MyDownloadAndParse.go();
	    System.out.println("DATA ACQUIRED");
	}
	
	//ritorna i dati
	@GetMapping("/data")
	public List<MyClass> getData() {
		return results;
	}
	
	//ritorna i metadati
	@GetMapping("/metadata")
	public Map<String,String> getMetadata() {
		return MyClass.getMetadata();
	}
	
	//ritorna le statistiche sui dati filtrati tramite il JSON scritto nel body di Postman nella forma 
	//{"attributo": {"condizione": valore}} per i numeri
	//{"attributo" : {"condizione" : [valore1, valore2, ...]}} per le stringhe
	@PostMapping("/filter")
	public Map<String,Double> callFilter(@RequestBody Map<String,Map> body) {
		
		//mappa di errore che viene usata se i parametri non sono validi
		Map<String,Double> e=new HashMap<String,Double>();
		
		//il valore dell' attributo da filtrare viene messo dentro "field"
		String field = body.keySet().toString();
		field=field.substring(1,field.length()-1);
		//la condizione del filtro viene messa dentro "condition"
		String condition = body.get(field).keySet().toString();
		condition=condition.substring(1,condition.length()-1);
		//il valore di riferimento per il filtro viene messo dentro "value"
		Object value =body.get(field).get(condition);
		
		//controllo se l' attributo da filtrare è contenuto tra gli attributi della classe MyClass
		if(MyClass.getMetadata().keySet().contains(field)) {
			
			//controllo se il valore di riferimento è un numero
			if(value instanceof Number) {
				
				//controllo se la condizione è "greater than" ossia ">"
				if(condition.equals("$gt")) {
					
					return MyStats.runStat(MyFilter.runFilt(results, field, ">", value), field);
				
				//controllo se la condizione è "lower than" ossia "<"
				}else if(condition.equals("$lt")) {
					
					return MyStats.runStat(MyFilter.runFilt(results, field, "<", value), field);
					
				}else {
					
					e.put("ERROR: NUMBER CONDITION IS NOT $gt OR $lt", null);
					return e;
				}
			
			//controllo se il valore di riferimento è un array di stringhe
			}else if(value instanceof ArrayList<?>){
				
				//controllo se la condizione è che debbano essere presi i valori coincidenti con gli elementi dell' array
				if(condition.equals("$in")) {
					
					return MyStats.runStat(MyFilter.runFilt(results, field, "in", value), field);
				
				//controllo se la condizione è che debbano essere presi i valori NON coincidenti con gli elementi dell' array
				}else if(condition.equals("$nin")) {
				
					return MyStats.runStat(MyFilter.runFilt(results, field, "nin", value), field);
					
				}else {
					
					e.put("ERROR: STRING[] CONDITION IS NOT $in OR $nin", null);
					return e;
				}
				
			}else {
				
				e.put("ERROR: PARAMETER IS NOT NUMBER OR STRING[]", null);
				return e;
			}
			
		}else {
			
			e.put("ERROR: FIELD DOES NOT EXIST", null);
			return e;
		}
	}
}
