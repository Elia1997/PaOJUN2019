package project.oop.myapp.actions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.ParseException;

import project.oop.myapp.model.MyClass;

public class MyDownloadAndParse {

	public static List<MyClass> go() {

		//controllo se il file esiste già
		File checkF=new File("FundsBreakdown.csv");
		
		if(!checkF.exists()) {
			
			//inserisce del PRIMO URL nella variabile "url"
			String url = "http://data.europa.eu/euodp/data/api/3/action/package_show?id=breakdown-available-funds-by-theme-2007-2013";
		
			try {
			
				//crea oggetto URLConnection per collegarsi al PRIMO URL
				URLConnection openConnection = new URL(url).openConnection();
			
				//crea oggetto InputStream e ci mette il contenuto della pagina indicata dal PRIMO URL
				InputStream in = openConnection.getInputStream();
			
				//Dichiara due stringhe vuote
				String data = "";
				String line = "";
			 
				try {
				 
					//InputStreamReader serve a convertire i byte di InputStream in char
					InputStreamReader inR = new InputStreamReader(in);
			   
					//BufferedReader migliora l' efficienza di lettura di InputStreamReader
					BufferedReader buf = new BufferedReader(inR);

					//mette ogni riga del contenuto della pagina indicata dal PRIMO URL dentro la variabile "data"
					while ((line = buf.readLine()) != null ) {
						data+=line;
					}
			   
				} finally {
				 
					//chiude la connessione
					in.close();
				}
			
				//crea un oggetto JSON col parsing di "data"
				JSONObject obj = (JSONObject) JSONValue.parseWithException(data); 
			
				//mette dentro objI il campo "result"
				JSONObject objI = (JSONObject) (obj.get("result"));
			
				//mette dentro l' array objA il campo "resources"
				JSONArray objA = (JSONArray) (objI.get("resources"));
			
				//per ogni elemento dell' array objA
				for(Object o: objA){
				
					//se l' elemento � di tipo JSONObject
					if ( o instanceof JSONObject ) {
			    	
						//copia il contenuto dell' elemento in "o1"
						JSONObject o1 = (JSONObject)o; 
			        
						//mette nella stringa "format" il valore del campo "format" dell' elemento
						String format = (String)o1.get("format");
			        
						//mette nella stringa "urID" il valore del campo "url" dell' elemento
						String urlD = (String)o1.get("url");
			        
						//se la stringa "format" contiente "CSV" (quello che ci interessa)
						if(format.contains("CSV")) {
			        		
							//scarica il file con URL=urID e lo salva come "ComradePolloSuper.csv"
							download(urlD, "FundsBreakdown.csv");
							System.out.println("FILE DOWNLOADED");
			        		
						}
					}
				}
			}catch(UnknownHostException e){
				System.out.println("DNS ERROR");
			} catch (IOException | ParseException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else {
			System.out.println("FILE ALREADY EXISTS, NO NEED TO DOWNLOAD");
		}
		
		//ritorno la lista di oggetti MyClass
	    return parseFile();
	}
	
	public static void download(String url, String fileName) throws Exception {
	    try (InputStream in = URI.create(url).toURL().openStream()) {
	        Files.copy(in, Paths.get(fileName));
	    }
	}
	
	public static List<MyClass> parseFile() {

		Pattern pattern = Pattern.compile(",");
		
		//creo una lista che conterr� oggetti del tipo MyClass
		List<MyClass> myList = new ArrayList<MyClass>();
				
		try{
			
			//apro il file csv
			BufferedReader bufCSV = new BufferedReader(new FileReader("FundsBreakdown.csv"));
			
			//leggo la prima riga del file contenente il nome degli attributi perch� causerebbe errori di conversione successivamente
			String line = bufCSV.readLine();
			
			//eseguo le istruzioni seguenti per ogni riga del file csv
			while ((line = bufCSV.readLine()) != null ) {
				
				if(line.contains("\"")) {
					
					for(int i=line.indexOf("\"");i<line.lastIndexOf("\"");i++) {
						if (line.charAt(i)==',') {
							line = line.substring(0, i)+""+line.substring(i + 1); 
						}
					}
				}
				
				//ogni dato separato dalla virgola viene messo in un array di stringhe
				String[] bufline= pattern.split(line);				
				
				if(bufline.length<5) {
					String[] buftemp= {"","0","","0","0"};
					for(int i=0;i<bufline.length;i++) {
						buftemp[i]=bufline[i];
					}
					myList.add(new MyClass(buftemp[0],Integer.parseInt(buftemp[1]),buftemp[2],Long.parseLong(buftemp[3]),Float.parseFloat(buftemp[4])));
				}else {
					//aggiungo alla lista un oggetto creato con i dati precedentemente ricavati (e convertiti a seconda del tipo di attributi)
					myList.add(new MyClass(bufline[0],Integer.parseInt(bufline[1]),bufline[2],Long.parseLong(bufline[3]),Float.parseFloat(bufline[4])));
				}
			}
			
			//chiudo il file csv
			bufCSV.close();
			
		}catch(FileNotFoundException e) {
			System.out.println("FILE INESISTENTE");
		}catch(IOException e) {
			System.out.println("ERRORE I/O");
		}catch(NumberFormatException e){	
			System.out.println("ERRORE DI CONVERSIONE");
		}catch(Exception e){	
			System.out.println("ERRORE GENERICO");
		}
		
		//ritorno la lista di oggetti MyClass
		return myList;
	}
	
}
