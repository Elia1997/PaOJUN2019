package projectAlpha;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyStats {

	
	public Map<String, Double> Stats(List<MyClass> src, String fieldName) {
		
		//creo una Map che conterr� le statistiche sui numeri o sulle stringhe
		Map<String, Double> results = new HashMap<String, Double>();
		//creo una List per memorizzare i numeri che saranno usati per calcolare la deviazione standard
		List<Double> numsfordevStd = new ArrayList<Double>();
		
		//inizializzo tutte le statische relative ai numeri
		Double min=0.0;
		Double max=0.0;
		Double devStd=0.0;
		Double sum=0.0;
		Double count=0.0;
		
		//per ogni elemento della List passata come parametro
		for(MyClass item : src) {
			
			try {
				
				//uso questo oggetto per poter ricavare i dati qualsiasi sia il campo che voglio filtrare (numero o stringa)
				Method m = item.getClass().getMethod("get"+fieldName.substring(0, 1).toUpperCase()+fieldName.substring(1),null);
				
				try {
					
					//dentro "tmp" ci finisce il risultato della chiamata del metodo precedente
					Object tmp = m.invoke(item);
					
					//incremento il counter prima dell' if perch� il conteggio degli elementi � richiesto sia per
					//i numeri che per le stringhe
					count++;
					
					//se il dato � un numero
					if(tmp instanceof Number) {
						
						//converto il dato in Double
						Double tmpC=((Number)tmp).doubleValue();
						
						//aggiungo il dato alla List per la deviazione standard
						numsfordevStd.add(tmpC);
						
						//aggiungo il dato alla variabile somma
						sum+=(tmpC);
						
						//se � il primo dato letto allora lo setto sia come massimo che come minimo
						if(count==1) {
							max=tmpC;
							min=tmpC;
						}else {
							
							//altrimenti se � maggiore del massimo allora diventa massimo
							if(tmpC>max){
								max=tmpC;
							}
							
							//altrimenti se � minore del minimo allora diventa minimo
							if(tmpC<min) {
								min=tmpC;
							}
						}
						
					//se il dato � una stringa
					}else if(tmp instanceof String) {
						
						//controllo se � gi� presente nella mappa
						if(results.containsKey((String)tmp)) {
							
							//in caso incremento di 1 il valore dell' occorenza
							results.replace((String)tmp, results.get(tmp)+1.0);
							
						}else {
							
							//se non � presente nella mappa la aggiungo e setto l' occorrenza a 1
							results.put((String)tmp, 1.0);
						}
						
					}
					
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				}
				
			} catch (NoSuchMethodException e) {
				e.printStackTrace();
			} catch (SecurityException e) {
				e.printStackTrace();
			}					
		}
		
		//controllo che la statistica sia inerente ai numeri, in questo caso la somma sar� al 99% diversa da 0
		//(l' eccezione sarebbe che tutti i dati sono nulli o ce ne sono alcuni negativi)
		
		if(sum!=0.0) {
			
			//calcolo la deviazione standard
			for(Double val:numsfordevStd) {
				devStd+= Math.pow(val - sum/count, 2);
			}
			
			//inserisco tutte le statistiche nella Map
			results.put("minimo", min);
			results.put("massimo", max);
			results.put("somma", sum);
			results.put("media", sum/count);
			results.put("deviazioneStandard", Math.sqrt(devStd/count));
			
		}
		
		//inserisco l' unico elemento in comune a entrambi i tipi di statistica
		results.put("numeroElementi", count);
		
		//faccio tornare la mappa coi risultati, sia per statistiche su stringe che su numeri
		return results;
		
	}
}