package project.oop.myapp.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import project.oop.myapp.model.MyClass;
import project.oop.myapp.actions.MyDownloadAndParse;

@RestController
public class MyController {
	
	private List<MyClass> results= new ArrayList<MyClass>();
	
	@EventListener(ApplicationReadyEvent.class)
	public void downloadAfterStartup() {
	    results=MyDownloadAndParse.go();
	    System.out.println("dati acquisiti");
	}
	
	@GetMapping("/results")
	public List<MyClass> getResults() {
		return results;
	}
	
	@GetMapping("/hello")
	public MyClass exampleMethod(@RequestParam(name="param1", defaultValue="World") String param1) {
		return new MyClass();
	}
	
	@PostMapping("/hello")
	public MyClass exampleMethod2(@RequestBody MyClass body) {
		return body;
	}
}
